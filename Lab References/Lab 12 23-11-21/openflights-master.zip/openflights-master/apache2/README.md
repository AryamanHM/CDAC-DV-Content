Copy these into /etc/apache2/sites-available.

-local is for local testing, -le-ssl is Let's Encrypt SSL.

Modules required: mod_include, mod_rewrite, mod_deflate, mod_php5


java -jar JsTestDriver.jar --port 9876 &
echo "Browse to http://localhost:9876/capture in a browser, then execute ./run_tests.sh"


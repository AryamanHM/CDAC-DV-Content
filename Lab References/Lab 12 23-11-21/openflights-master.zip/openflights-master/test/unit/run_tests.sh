java -jar JsTestDriver.jar --tests all


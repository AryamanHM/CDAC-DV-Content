<?php
header("Location: /data.html")
?>

